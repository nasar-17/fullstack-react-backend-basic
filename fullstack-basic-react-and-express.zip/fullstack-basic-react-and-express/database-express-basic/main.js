const express = require("express")
const mysql = require('mysql')
const app = express()
const cors = require('cors')

app.use(cors())

const database = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'name-your-database'
})

database.connect((err) => {
    if(err) throw err;
    console.log('Database Connected')
})
// ambil semua data users
app.get("/api/v1/users", (req, res) => {
    console.log('GET API');
    database.query('SELECT * FROM users', (err, rows) => {
        if(err) throw err;
        res.json({
            succes: true,
            message: 'getting users data',
            data: rows,
        });
    })
})

app.listen(3001, () => {
    console.log('Server is running in port 3001')
})