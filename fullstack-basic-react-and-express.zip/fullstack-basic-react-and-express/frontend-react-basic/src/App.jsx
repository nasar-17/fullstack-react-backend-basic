import { useEffect, useState } from 'react';
import './App.css';

const endpoint = 'http://localhost:3001/api/v1/users';

function App() {
  const [users, setUsers] = useState([]);

  const fetchUser = async () => {
    const response = await fetch(endpoint);
    const result = await response.json();
    console.log("RESPON API:", result); // Debugging
    setUsers(result.data); // Ambil array data-nya
  };

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <>
      <h1>testing</h1>
      {users.map((user) => (
        <div key={user.id}>
          <p>{user.username}</p>
        </div>
      ))}
    </>
  );
}

export default App;


// ✨ Kesimpulan
// ✅ Kode kamu bisa jalan karena users?.data?.map(...) memakai optional chaining.

// 🚫 Tapi itu tanda bahwa kamu menyimpan objek, bukan array langsung.

// ✅ Lebih baik ubah setUsers(data.data) agar users langsung array dan tidak perlu .data saat render.